<?php

return [
    'CART_LIMIT' => 6,
];
