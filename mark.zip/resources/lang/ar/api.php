<?php

return [

    'Register Complete'=>'اكتمل التسجيل',
    'login successfully'=>'تم التسجيل بنجاح',
    'Incorrect Email Or Password'=>'بريد أو كلمة مرورغير صحيحة',
    'This Account has been blocked, check our policies'=>'تم حظر هذا الحساب ، تحقق من سياساتنا',
    'All Roles retrieved successfully'=>'تم استرداد جميع الأدوار بنجاح',
    'There is no roles for this store'=>'تم استرداد جميع الأدوار بنجاح',


];
