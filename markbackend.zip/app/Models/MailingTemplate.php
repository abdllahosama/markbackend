<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MailingTemplate extends Model
{
	protected $table = 'mailing_templates';
	protected $guarded = [];


}
