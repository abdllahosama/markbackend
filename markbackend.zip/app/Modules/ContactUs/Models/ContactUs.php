<?php

namespace App\Modules\ContactUs\Models;

use Illuminate\Database\Eloquent\Model;

class ContactUs extends Model

{

    protected $table = 'contacts';

    protected $guarded = [];

}
