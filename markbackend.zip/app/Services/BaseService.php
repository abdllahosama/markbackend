<?php

namespace App\Services;

use App\Traits\DashboardResponseTrait;

class BaseService
{
    use DashboardResponseTrait;
}
