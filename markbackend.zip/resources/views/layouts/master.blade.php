<!DOCTYPE html>
<html lang="ar" dir="rtl">

@include('layouts.head')

<body>

    @include('layouts.start-wraper')

    @yield('content')

    @include('layouts.end-wraper')

</body>

</html>
