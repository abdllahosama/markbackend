<?php

return [

    'Register Complete'=>'Register Complete',
    'login successfully'=>'login successfully',
    'Incorrect Email Or Password'=>'Incorrect Email Or Password',
    'This Account has been blocked, check our policies'=>'This Account has been blocked, check our policies',
    'All Roles retrieved successfully'=>'All Roles retrieved successfully',
    'There is no roles for this store'=>'لا توجد أدوار لهذا المتجر',


];
